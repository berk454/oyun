ROBLOX 2 ONLINE v1.2

Bu paket iki parçadır:

1) godot/
Gerçek oyun istemcisi. Godot 4 ile açılır.
Windows EXE ve Android APK olarak export edilebilir.

2) server/
Node.js WebSocket sunucusu.
Arkadaşların aynı odaya girmesi, online durum ve chat için kullanılır.

SUNUCU:
  cd server
  npm install
  node server.js

ÖNEMLİ:
İstemcide scripts/main.gd içindeki:
  ws.connect_to_url("ws://127.0.0.1:8080")
adresini internete koyacağın sunucunun adresiyle değiştir.
Örneğin:
  wss://oyunun-sunucusu.example.com

Güvenli gerçek internet kullanımı için WSS önerilir.

ARKADAŞA KATIL:
Bir arkadaş online ise sunucu onun oda bilgisini paylaşır.
Arkadaş listesinde "KATIL" akışıyla aynı odaya geçilir.

CHAT:
Aynı odadaki oyuncuların mesajları yayınlanır.
