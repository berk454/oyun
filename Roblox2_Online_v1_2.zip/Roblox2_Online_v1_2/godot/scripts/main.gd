extends Node2D

# Roblox 2 Online v1.2
# Arkadaş listesi, parti/katıl akışı ve sohbet için WebSocket istemci iskeleti.
# Gerçek internet çok oyuncululuğu için server/server.js çalıştırılmalıdır.

var player_name := "Oyuncu"
var player_id := ""
var ws := WebSocketPeer.new()
var connected := false
var room := "obby-1"
var chat_messages: Array[String] = []
var friends: Array[String] = []
var online_friends: Array[String] = []
var remote_players := {}

var player_pos := Vector2(120, 560)
var player_vel := Vector2.ZERO
var grounded := false
var camera_x := 0.0
var started := false
var finished := false
var left := false
var right := false
var jump := false

var platforms = [
    Rect2(0,620,650,100), Rect2(760,560,190,30), Rect2(1040,500,190,30),
    Rect2(1320,440,190,30), Rect2(1600,510,190,30), Rect2(1880,450,190,30),
    Rect2(2160,390,240,30), Rect2(2500,330,400,30)
]

var font: Font

func _ready():
    font = ThemeDB.fallback_font
    player_id = str(Time.get_unix_time_from_system()) + "-" + str(randi() % 99999)
    connect_to_server()
    queue_redraw()

func connect_to_server():
    var err = ws.connect_to_url("ws://127.0.0.1:8080")
    if err != OK:
        chat_messages.push_back("Sunucuya bağlanılamadı. Yerel moddasın.")

func _process(delta):
    ws.poll()
    var state = ws.get_ready_state()
    if state == WebSocketPeer.STATE_OPEN and not connected:
        connected = true
        send_json({"type":"hello","id":player_id,"name":player_name,"room":room})
        chat_messages.push_back("🟢 Online sunucuya bağlandın.")
    elif state == WebSocketPeer.STATE_CLOSED and connected:
        connected = false

    while ws.get_available_packet_count() > 0:
        var text = ws.get_packet().get_string_from_utf8()
        handle_server_message(text)

    if started and not finished:
        update_game(delta)
    queue_redraw()

func send_json(data: Dictionary):
    if ws.get_ready_state() == WebSocketPeer.STATE_OPEN:
        ws.send_text(JSON.stringify(data))

func handle_server_message(text: String):
    var data = JSON.parse_string(text)
    if typeof(data) != TYPE_DICTIONARY:
        return
    match data.get("type",""):
        "chat":
            chat_messages.push_back(str(data.get("name","Oyuncu")) + ": " + str(data.get("message","")))
            if chat_messages.size() > 8: chat_messages.pop_front()
        "presence":
            online_friends.clear()
            for p in data.get("players",[]):
                if p.get("id","") != player_id:
                    remote_players[p.get("id","")] = p
                    online_friends.push_back(str(p.get("name","Oyuncu")))
        "state":
            if data.get("id","") != player_id:
                remote_players[data.get("id","")] = data
        "join_room":
            room = str(data.get("room",room))
            chat_messages.push_back("➡ Arkadaşının odasına katıldın: " + room)
        "friend_added":
            friends.append(str(data.get("name","Oyuncu")))
            chat_messages.push_back("👥 Arkadaş eklendi: " + str(data.get("name","")))

func send_chat(message: String):
    message = message.strip_edges()
    if message.is_empty(): return
    send_json({"type":"chat","room":room,"name":player_name,"message":message})

func add_friend(name: String):
    name = name.strip_edges()
    if name.is_empty(): return
    if name in friends: return
    send_json({"type":"add_friend","name":name})

func join_friend(name: String):
    send_json({"type":"join_friend","name":name})

func update_game(delta):
    var dir := 0.0
    if Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT) or left: dir -= 1
    if Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT) or right: dir += 1
    player_vel.x = dir * 320.0
    if (Input.is_key_pressed(KEY_SPACE) or Input.is_key_pressed(KEY_W) or jump) and grounded:
        player_vel.y = -620
        grounded = false
    jump = false
    player_vel.y = min(player_vel.y + 1500.0 * delta, 1100.0)
    var old_y = player_pos.y
    player_pos += player_vel * delta
    grounded = false
    for p in platforms:
        var r = Rect2(player_pos, Vector2(36,54))
        if player_vel.y >= 0 and r.intersects(p) and old_y + 54 <= p.position.y + 8:
            player_pos.y = p.position.y - 54
            player_vel.y = 0
            grounded = true
    if player_pos.y > 900:
        player_pos = Vector2(120,560)
        player_vel = Vector2.ZERO
    camera_x = max(0.0, player_pos.x - 360.0)
    send_json({"type":"state","room":room,"id":player_id,"name":player_name,"x":player_pos.x,"y":player_pos.y})

func _input(event):
    if event is InputEventKey and event.pressed:
        if event.keycode == KEY_ENTER and started:
            # Chat UI is intentionally kept simple in this first online build.
            send_chat("Merhaba!")
        if event.keycode == KEY_ESCAPE:
            get_tree().quit()

func _draw():
    var size = get_viewport_rect().size
    draw_rect(Rect2(0,0,5000,900),Color("#82cef8"))
    draw_circle(Vector2(1100-camera_x*.15,110),55,Color("#ffe16b"))
    for i in range(12):
        var x=float(i*500)-camera_x*.2
        draw_colored_polygon(PackedVector2Array([Vector2(x,620),Vector2(x+220,330),Vector2(x+500,620)]),Color("#8fb9c7"))
    for p in platforms:
        var r=Rect2(p.position.x-camera_x,p.position.y,p.size.x,p.size.y)
        draw_rect(r,Color("#35a853"))
        draw_rect(Rect2(r.position,Vector2(r.size.x,8)),Color("#68d276"))

    # Uzaktaki arkadaş karakterleri
    for id in remote_players:
        var rp=remote_players[id]
        var q=Vector2(float(rp.get("x",0))-camera_x,float(rp.get("y",560)))
        draw_rect(Rect2(q.x+2,q.y+18,34,24),Color("#9b59ff"))
        draw_rect(Rect2(q.x+4,q.y-12,28,30),Color("#ffc58f"))
        draw_string(font,q+Vector2(-2,-20),str(rp.get("name","Arkadaş")),HORIZONTAL_ALIGNMENT_LEFT,-1,14,Color.WHITE)

    # Kendi karakterin
    var pp=Vector2(player_pos.x-camera_x,player_pos.y)
    draw_rect(Rect2(pp.x+4,pp.y+37,10,17),Color("#242424"))
    draw_rect(Rect2(pp.x+22,pp.y+37,10,17),Color("#242424"))
    draw_rect(Rect2(pp.x+2,pp.y+18,34,24),Color("#168cff"))
    draw_rect(Rect2(pp.x+4,pp.y-12,28,30),Color("#ffc58f"))
    draw_rect(Rect2(pp.x+4,pp.y-12,28,8),Color("#542f20"))
    draw_string(font,pp+Vector2(-2,-21),player_name,HORIZONTAL_ALIGNMENT_LEFT,-1,14,Color.WHITE)

    # Menü / durum
    draw_rect(Rect2(14,14,370,45),Color(0.05,0.07,0.11,0.84))
    draw_string(font,Vector2(28,43),"ROBLOX 2  •  "+("ONLINE" if connected else "OFFLINE"),HORIZONTAL_ALIGNMENT_LEFT,-1,18,Color.WHITE)

    # Arkadaş paneli
    draw_rect(Rect2(size.x-330,14,316,235),Color(0.05,0.07,0.11,0.90))
    draw_string(font,Vector2(size.x-310,45),"👥 ARKADAŞLAR",HORIZONTAL_ALIGNMENT_LEFT,-1,21,Color("#27a9ff"))
    var y=78
    if online_friends.is_empty():
        draw_string(font,Vector2(size.x-310,y),"Online arkadaş yok.",HORIZONTAL_ALIGNMENT_LEFT,-1,17,Color("#b8c3d3"))
    else:
        for n in online_friends.slice(0,5):
            draw_circle(Vector2(size.x-300,y-5),6,Color("#35d06f"))
            draw_string(font,Vector2(size.x-285,y),n,HORIZONTAL_ALIGNMENT_LEFT,-1,16,Color.WHITE)
            draw_string(font,Vector2(size.x-165,y),"▶ KATIL",HORIZONTAL_ALIGNMENT_LEFT,-1,15,Color("#ffd43b"))
            y+=32

    # Chat
    draw_rect(Rect2(14,size.y-205,390,180),Color(0.05,0.07,0.11,0.86))
    draw_string(font,Vector2(28,size.y-175),"💬 CHAT",HORIZONTAL_ALIGNMENT_LEFT,-1,19,Color("#27a9ff"))
    y=size.y-145
    for m in chat_messages.slice(max(0,chat_messages.size()-6),chat_messages.size()):
        draw_string(font,Vector2(28,y),m,HORIZONTAL_ALIGNMENT_LEFT,355,14,Color.WHITE)
        y+=22
    draw_string(font,Vector2(28,size.y-37),"Enter: hızlı mesaj • Arkadaş katılımı sunucu üzerinden",HORIZONTAL_ALIGNMENT_LEFT,-1,12,Color("#aeb8c7"))
