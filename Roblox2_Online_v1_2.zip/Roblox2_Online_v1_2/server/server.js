// Roblox 2 Online Server v1.2
// Node.js 18+
// Kurulum: npm install ws
// Çalıştır: node server.js
//
// İnternete açmak için bu sunucuyu bir VPS/hosting üzerinde çalıştırıp
// istemcideki ws://127.0.0.1:8080 adresini kendi WSS adresinle değiştir.

const WebSocket = require("ws");
const wss = new WebSocket.Server({ port: 8080 });

const players = new Map();
const friends = new Map();

function broadcastRoom(room, obj) {
  const msg = JSON.stringify(obj);
  for (const p of players.values()) {
    if (p.room === room && p.ws.readyState === WebSocket.OPEN) p.ws.send(msg);
  }
}
function presence(room) {
  const list = [...players.values()]
    .filter(p => p.room === room)
    .map(p => ({id:p.id,name:p.name,x:p.x,y:p.y}));
  broadcastRoom(room, {type:"presence", players:list});
}

wss.on("connection", ws => {
  let me = null;

  ws.on("message", raw => {
    let d;
    try { d = JSON.parse(raw.toString()); } catch { return; }

    if (d.type === "hello") {
      me = {ws, id:String(d.id), name:String(d.name||"Oyuncu"), room:String(d.room||"obby-1"), x:120, y:560};
      players.set(me.id, me);
      ws.send(JSON.stringify({type:"chat",name:"Sistem",message:"Sunucuya hoş geldin!"}));
      presence(me.room);
      return;
    }

    if (!me) return;

    if (d.type === "chat") {
      const message = String(d.message||"").slice(0,180);
      if (message) broadcastRoom(me.room,{type:"chat",name:me.name,message});
    }

    if (d.type === "state") {
      me.x = Number(d.x)||0; me.y = Number(d.y)||0;
      broadcastRoom(me.room,{type:"state",id:me.id,name:me.name,x:me.x,y:me.y});
    }

    if (d.type === "join_friend") {
      const target = [...players.values()].find(p => p.name.toLowerCase() === String(d.name||"").toLowerCase());
      if (target) {
        me.room = target.room;
        ws.send(JSON.stringify({type:"join_room",room:me.room}));
        presence(me.room);
      } else {
        ws.send(JSON.stringify({type:"chat",name:"Sistem",message:"Bu arkadaş şu an çevrim içi değil."}));
      }
    }

    if (d.type === "add_friend") {
      const targetName = String(d.name||"").trim();
      if (targetName) {
        friends.set(me.name, [...(friends.get(me.name)||[]), targetName]);
        ws.send(JSON.stringify({type:"friend_added",name:targetName}));
      }
    }
  });

  ws.on("close", () => {
    if (me) {
      players.delete(me.id);
      presence(me.room);
    }
  });
});

console.log("Roblox 2 Online Server çalışıyor: ws://127.0.0.1:8080");
